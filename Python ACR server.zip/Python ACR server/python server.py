import cmd
from ctypes.wintypes import PMSG
from cloudlink import CloudLink
from playsound import playsound
  
# for playing note.wav file


"""
CloudLink v0.1.7 Client Example

This code demonstrates how easy it is to connect to a server. It also shows how to write functions
to interact with CloudLink.

For more information, please visit https://hackmd.io/G9q1kPqvQT6NrPobjjxSgg
"""

def on_connect():
    print("I am now connected!")
    cl.sendPacket({"cmd": "setid", "val": "server"})

def on_error(error):
    playsound('./alert.wav')
    cl = CloudLink(debug=True) 
    print("Oops, I got an error! {0}".format(error))
    cl.callback("on_packet", on_packet)
    cl.callback("on_error", on_error)
    cl.callback("on_connect", on_connect)
    cl.callback("on_close", on_close)
    # Create callbacks to functions.
    cl.client("wss://cloudserver1.cst1229.repl.co/")
    cl.client()

def on_packet(message):
    playsound('./alert.wav')
    print("I got a new message! " + message)
    if "pvar" in message:
        print("private var")
        varuser = message.split('"origin": ')
        varuser = (varuser[-1])
        varuser = (varuser.replace("}", ""))
        varuser = (varuser.replace('"', ""))
        varuser = (varuser.replace(',', ""))
        varname = message.split('"name": ')
        varname = (varname[-1])
        varname = (varname.replace("}", ""))
        varname = (varname.replace('"', ""))
        varname = (varname.replace(',', ""))
        varname = (varname.replace('origin:', ""))
        varname = (varname.replace(varuser, ""))
        varvalue = message.split('"val": ')
        varvalue = (varvalue[-1])
        varvalue = (varvalue.replace("}", ""))
        varvalue = (varvalue.replace('"', ""))
        varvalue = (varvalue.replace(',', ""))
        varvalue = (varvalue.replace('origin:', ""))
        varvalue = (varvalue.replace('name:', ""))
        varvalue = (varvalue.replace(varuser, ""))
        varvalue = (varvalue.replace(varname, ""))
        varvalue = (varvalue.replace(' ', ""))
        print (varuser)
        print (varname)
        print (varvalue)
        if "level" in (varname):
            f = open("./Temp/levelvaruser.txt", "w")
            f.write(varuser)
            f.close()
            f = open("./Temp/levelvarname.txt", "w")
            f.write(varname)
            f.close()
            f = open("./Temp/levelvarvalue.txt", "w")
            f.write(varvalue)
            f.close()
        elif "code" in (varname):
            f = open("./Temp/codevaruser.txt", "w")
            f.write(varuser)
            f.close()
            f = open("./Temp/codevarname.txt", "w")
            f.write(varname)
            f.close()
            f = open("./Temp/codevarvalue.txt", "w")
            f.write(varvalue)
            f.close()
                
        elif "verify" in (varname):
            f = open("./Temp/infovaruser.txt", "w")
            f.write(varuser)
            f.close()
            f = open("./Temp/infovarname.txt", "w")
            f.write(varname)
            f.close()
            f = open("./Temp/infovarvalue.txt", "w")
            f.write(varvalue)
            f.close()
        elif "password" in (varname):
            f = open("./Temp/pskvaruser.txt", "w")
            f.write(varuser)
            f.close()
            f = open("./Temp/pskvarname.txt", "w")
            f.write(varname)
            f.close()
            f = open("./Temp/pskvarvalue.txt", "w")
            f.write(varvalue)
            f.close()
        else:
            f = open("./Temp/varuser.txt", "w")
            f.write(varuser)
            f.close()
            f = open("./Temp/varname.txt", "w")
            f.write(varname)
            f.close()
            f = open("./Temp/varvalue.txt", "w")
            f.write(varvalue)
            f.close()
    

                    
    if "pmsg" in message:
        f = open("./Temp/infovarvalue.txt", "r+")
        info = f.read()
        f.close()
        f = open("./Temp/codevarvalue.txt", "r+")
        code = f.read()
        f.close()
        f = open("./Codes/codes.txt", "r+")
        codes = f.read()
        f.close()
        f = open("./Codes/validinfo.txt", "r+")
        validinfo = f.read()
        f.close()
        f = open("./Codes/defualtcodes.txt", "r+")
        okcodes = f.read()
        f.close()
        f = open("./Temp/codevaruser.txt", "r+")
        codeuser = f.read()
        f.close()
        if code in okcodes:
            print("Is a valid code")
            if code in codes:
                print("Code seen before, verifying...")
                if info in validinfo:
                    cl.sendPacket({"cmd": "gmsg", "val": "ACTOK"+code, "id": "server"})
                    
            else:
                print("creating code ID")
                cl.sendPacket({"cmd": "gmsg", "val": "ACTOK"+code, "id": "server"})
                # Open a file with access mode 'a'
                with open("./Codes/codes.txt", "a") as file_object:
                    # Append at the end of file
                    file_object.write(code+'\n')
                with open("./Codes/validinfo.txt", "a") as file_object:
                    # Append at the end of file
                    file_object.write(info+'\n')
                
        print("inbound dm")
        user = message.split('"origin": ')
        user = (user[-1])
        user = (user.replace("}", ""))
        user = (user.replace('"', ""))
        print (user)
        content = message.split('"val": ')
        content = (content[-1])
        content = (content.replace("}", ""))
        content = (content.replace('"', ""))
        content = (content.replace("origin:", ""))
        content = (content.replace(',', ""))
        content = (content.replace(user, ""))
        print (content)
        import os


        if "4" in content:
            print("Saving beta informatio for " + user)
            f = open("./Temp/varvalue.txt", "r")
            userdata=f.read()
            f.close()
            f = open("./Users/" + (user) + "/beta-info.txt", "a+")
            f.write(userdata + "\n \n")
            f.close()

        if "3" in content:
            print("Checking login information and saving for " + user)
            f = open("./Users/" + (user) + "/password.txt", "r")
            userpassword=f.read()
            f.close()
            f = open("./Temp/pskvaruser.txt", "r")
            tempvaruser=f.read()
            f.close()
            f = open("./Temp/pskvarname.txt", "r")
            tempvarname=f.read()
            f.close()
            f = open("./Temp/pskvarvalue.txt", "r")
            tempvarvalue=f.read()
            f.close()
            f = open("./Temp/levelvarname.txt", "r")
            levelvarname=f.read()
            f.close()
            f = open("./Temp/levelvaruser.txt", "r")
            levelvaruser=f.read()
            f.close()
            tick=1
            if (user) in tempvaruser:
                print("made to user match")
                if "password" in tempvarname:
                    print("made to password name match")
                    if userpassword in tempvarvalue:
                        print("made to password match")
                        if (user) in levelvaruser:
                            print("made to level user match")
                            if "level" in(levelvarname):
                                print("made to level match")
                                f = open("./Temp/levelvarvalue.txt", "r")
                                levelvar=f.read()
                                f.close()
                                f = open("./Users/" + (user) + "/level.txt", "w")
                                f.write(levelvar)
                                f.close()
                                tick=0
                                print("Done writing level entries, phew, that took a while!")
                                cl.sendPacket({"cmd": "pmsg", "val": "OK! Level was updated!", "id": (user)})
            if tick == 1:
                cl.sendPacket({"cmd": "pmsg", "val": "ERR, Password does not match!", "id": (user)})

        if "2" in content:
            print("Checking login information for " + user)
            f = open("./Users/" + (user) + "/password.txt", "r")
            userpassword=f.read()
            f.close()
            f = open("./Temp/pskvaruser.txt", "r")
            tempvaruser=f.read()
            f.close()
            f = open("./Temp/pskvarname.txt", "r")
            tempvarname=f.read()
            f.close()
            f = open("./Temp/pskvarvalue.txt", "r")
            setpass=f.read()
            f.close()
            if (user) in tempvaruser:
                if "password" in tempvarname:
                    if userpassword in setpass:
                        f = open("./Users/" + (user) + "/level.txt", "r")
                        userlevel=f.read()
                        f.close()
                        cl.sendPacket({"cmd": "pmsg", "val": userlevel, "id": (user)})
                    
        if "1" in content:
            print("Creating acount for " + user)
            # Directory
            import shutil

            dir_path = './Users/' + user

            try:
                shutil.rmtree(dir_path)
            except OSError as e:
                print("Error: %s : %s" % (dir_path, e.strerror))
            directory = (user)
            
            # Parent Directory path
            parent_dir = "./Users"
            
            # Path
            path = os.path.join(parent_dir, directory)
            
            # Create the directory
            # 'GeeksForGeeks' in
            # '/home / User / Documents'
            os.mkdir(path)
            f = open("./Users/" + (user) + "/level.txt", "w")
            f.write("1")
            f.close()
            f = open("./Temp/pskvaruser.txt", "r")
            tempvaruser=f.read()
            f.close()
            f = open("./Temp/pskvarname.txt", "r")
            tempvarname=f.read()
            f.close()
            f = open("./Temp/pskvarvalue.txt", "r")
            tempvarvalue=f.read()
            f.close()
            if (user) in tempvaruser:
                f = open("./Users/" + (user) + "/password.txt", "w")
                f.write(tempvarvalue)
                f.close()
            print("Finished creating user profile for " + user)
            cl.sendPacket({"cmd": "pmsg", "val": "1", "id": (user)})

    
    """
    The on_packet callback differs in what it does when used in server
    mode than it does in client mode.
    
    In server mode, the on_packet callback will only return back packets
    sent using the "direct" command, and will return the value of "val".
    
    If a client sends {"cmd": "direct", "val": "test"}, the server will
    take this message and callback the on_packet callback here, only
    returning the value "test" as the message.
    
    In client mode, the message will return all JSON with only modifications
    to remove the ID (if we're sending packets to someone, they don't need extra
    garbage data telling that it's theirs), and adds the "origin" value to tell
    the client who the packet was sent from.
    
    As shown above, if a client sends {"cmd": "test", "val": "test", "id": "(YOUR ID HERE)"}
    to (YOUR ID HERE), the on_packet callback will return
    {"cmd" "test", "val": "test", "origin" "(CLIENT'S ID)"}
    """

def on_close():
    cl = CloudLink(debug=True) 
    print("Goodbye!")
    cl.callback("on_packet", on_packet)
    cl.callback("on_error", on_error)
    cl.callback("on_connect", on_connect)
    cl.callback("on_close", on_close)
    # Create callbacks to functions.
    cl.client("wss://cloudserver1.cst1229.repl.co/")
    cl.client()

if __name__ == "__main__":
    cl = CloudLink(debug=True) 
    # Instanciates a CloudLink object into memory.
    cl.callback("on_packet", on_packet)
    cl.callback("on_error", on_error)
    cl.callback("on_connect", on_connect)
    cl.callback("on_close", on_close)
    # Create callbacks to functions.
    cl.client("wss://cloudserver1.cst1229.repl.co/")
    cl.client()
    # Start CloudLink and run as a client.